﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity;

using System.Data.Entity.Validation;

namespace rvread.DAL
{
    public class VMrepo : Statusrepo, IAct<VM>
    {

        //bool disposed = false;
        public VMrepo() : base() { }
        public VMrepo(CloudTrackerDevEntities context) : base(context) { }

        public VM getvmbyname(string name)
        {
            VM vm;
            try
            {
                vm = getBasi().VMs.Where(s => s.name == name).SingleOrDefault();

            }catch(Exception e)
            {
                throw new Exception(exception(e));
            }
            return vm;
        }

        public void update(DataTable excel, int foreasid, int vmid,int row)
        {
            string log = "";
            VM vm = getBasi().VMs.Where(s => s.vmID == vmid).SingleOrDefault();
            string temp,query;
            try
            {
                for (int j = 0; j < excel.Columns.Count; j++)
                {
                    if ((string)excel.Rows[0][j] == "PowerOn")//είμαι στη Poweron
                        try
                        {
                            if (vm.poweron != DateTime.Parse(((string)excel.Rows[row][j]).Replace("/", "-")))//diafερει από τη τιμή που έχω
                                if (DateTime.Compare(getlastupdate("PowerOn", foreasid, vmid), ReadExcel.date) <= 0)//είναι παλιότερη
                                {
                                    try
                                    {
                                        log += String.Format("PoewrOn από {0} σε {1}", vm.poweron, (string)excel.Rows[row][j]);
                                        vm.poweron = DateTime.Parse(((string)excel.Rows[row][j]).Replace("/", "-"));//αλλάζω
                                    }
                                    catch (Exception e) { }
                                }
                        }
                        catch { }
                    //connection state
                    if ((string)excel.Rows[0][j] == "Connection state")
                    {
                        try
                        {
                            if (DateTime.Compare(getlastupdate("connectstateid_fk", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                try
                                {
                                    temp = (string)excel.Rows[row][j];
                                    query = "select id from vmConnectionstate where description='" + temp + "'";
                                    int id = addrecgetid(typeof(vmConnectionstate), temp, query);
                                    if (vm.connectstateid_fk != id) //an δεν έχει μπει, στον vmConnectionState exception
                                    {
                                        vm.connectstateid_fk = id;
                                        log += String.Format("connectstateid_fk από {0} σε {1}", vm.connectstateid_fk, id);
                                    }

                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    }
                    //config status
                    if ((string)excel.Rows[0][j] == "Config status")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("confstatusid_fk", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select id from vmConfigStatus where description='" + temp + "'";
                                try
                                {
                                    int id = addrecgetid(typeof(vmConfigStatu), temp, query);
                                    if (vm.confstatusid_fk != id)
                                    {
                                        log += String.Format("confstatusid_fk από {0} σε {1}", vm.confstatusid_fk, id);
                                        vm.confstatusid_fk = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    //heart beat
                    if ((string)excel.Rows[0][j] == "Heartbeat")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("heartbeatid_fk", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select id from vmHeartbeat where description='" + temp + "'";
                                try
                                {
                                    int id = addrecgetid(typeof(vmHeartbeat), temp, query);
                                    if (vm.heartbeatid_fk != id)
                                    {
                                        log += String.Format("heartbeatid_fk από {0} σε {1}", vm.heartbeatid_fk, id);
                                        vm.heartbeatid_fk = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    //dns name
                    if ((string)excel.Rows[0][j] == "DNS Name")
                        try
                        {
                            if (vm.DNSname != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("DNSname", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("DNSname από {0} σε {1}", vm.DNSname, (string)excel.Rows[row][j]);
                                    vm.DNSname = (string)excel.Rows[row][j];

                                }
                        }
                        catch { }
                    //cpu
                    if ((string)excel.Rows[0][j] == "CPUs")
                        try
                        {
                            if (vm.cpu != Convert.ToInt32((string)excel.Rows[row][j]))
                                if (DateTime.Compare(getlastupdate("cpu", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("cpu από {0} σε {1}", vm.cpu, (string)excel.Rows[row][j]);
                                    vm.cpu = Convert.ToInt32((string)excel.Rows[row][j]);
                                }
                        }
                        catch { }
                    //RAM
                    if ((string)excel.Rows[0][j] == "Memory")
                        try
                        {
                            if (vm.ram != Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", "")))
                                if (DateTime.Compare(getlastupdate("ram", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("ram από {0} σε {1}", vm.ram, (string)excel.Rows[row][j]);
                                    vm.ram = Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", ""));
                                }
                        }
                        catch { }
                    //PROVISION
                    if ((string)excel.Rows[0][j] == "Provisioned MB")
                        try
                        {
                            if (vm.storageprovision != Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", "")))
                                if (DateTime.Compare(getlastupdate("storageprovision", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("storageprovision από {0} σε {1}", vm.storageprovision, (string)excel.Rows[row][j]);
                                    vm.storageprovision = Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", ""));

                                }
                        }
                        catch { }
                    //IN USE
                    if ((string)excel.Rows[0][j] == "In Use MB")
                        try
                        {
                            if (vm.storageinuse != Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", "")))
                                if (DateTime.Compare(getlastupdate("storageinuse", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("storageinuse από {0} σε {1}", vm.storageinuse, (string)excel.Rows[row][j]);
                                    vm.storageinuse = Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", ""));
                                }
                        }
                        catch { }
                    //UNSHARE
                    if ((string)excel.Rows[0][j] == "Unshared MB")
                        try
                        {
                            if (vm.storageunshare != Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", "")))
                                if (DateTime.Compare(getlastupdate("storageunshare", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("storageunshare από {0} σε {1}", vm.storageunshare, (string)excel.Rows[row][j]);
                                    vm.storageunshare = Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", ""));
                                }
                        }
                        catch { }
                    //PATH
                    if ((string)excel.Rows[0][j] == "Path")
                        try
                        {
                            if (vm.pathvm != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("pathvm", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("pathvm από {0} σε {1}", vm.pathvm, (string)excel.Rows[row][j]);
                                    vm.pathvm = (string)excel.Rows[row][j];
                                }
                        }
                        catch { }
                    //NOTES
                    if ((string)excel.Rows[0][j] == "Annotation")
                        try
                        {
                            if (excel.Rows[row][j] != DBNull.Value && vm.notes != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("notes", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("notes από {0} σε {1}", vm.notes, (string)excel.Rows[row][j]);
                                    vm.notes = (string)excel.Rows[row][j];
                                }
                        }
                        catch { }
                    //resourcepool
                    if ((string)excel.Rows[0][j] == "Resource pool")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("poolid_fk", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select id from vmresourcepool where description='" + temp + "'";
                                try
                                {
                                    int id = (int)addrecgetid(typeof(vmresourcepool), temp, query);
                                    if (vm.poolid_fk != id)
                                    {
                                        log += String.Format("poolid_fk από {0} σε {1}", vm.poolid_fk, id);
                                        vm.poolid_fk = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    //CLUSTER
                    if ((string)excel.Rows[0][j] == "Cluster")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("clustertid_fk", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select id from vmCluster where description='" + temp + "'";
                                try
                                {
                                    int id = (int)addrecgetid(typeof(vmCluster), temp, query);
                                    if (vm.clustertid_fk != id)
                                    {
                                        log += String.Format("poolid_fk από {0} σε {1}", vm.clustertid_fk, id);
                                        vm.clustertid_fk = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    //HOST
                    if ((string)excel.Rows[0][j] == "Host")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("hostid_fk", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select id from vmHost where description='" + temp + "'";
                                try
                                {
                                    int id = addrecgetid(typeof(vmHost), temp, query);
                                    if (vm.hostid_fk != id)
                                    {
                                        log += String.Format("hostid_fk από {0} σε {1}", vm.hostid_fk, id);
                                        vm.hostid_fk = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }

                    //os config file
                    if ((string)excel.Rows[0][j] == "OS according to the configuration file")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("osconffile", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select osID from OperateSystem where description='" + temp + "'";
                                try
                                {
                                    int id = addrecgetid(typeof(OperateSystem), temp, query);
                                    if (vm.osconffile != id)
                                    {
                                        log += String.Format("osconffile από {0} σε {1}", vm.osconffile, id);
                                        vm.osconffile = id;
                                    }
                                }
                                catch (Exception e) { }

                            }
                        }
                        catch { }
                    //os  vmtools file
                    if ((string)excel.Rows[0][j] == "OS according to the VMware Tools")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("osconffile", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select osID from OperateSystem where description='" + temp + "'";
                                try
                                {
                                    int id = addrecgetid(typeof(OperateSystem), temp, query);
                                    if (vm.osvmtool != id)
                                    {
                                        log += String.Format("osvmtool από {0} σε {1}", vm.osvmtool, id);
                                        vm.osvmtool = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    //vmid
                    if ((string)excel.Rows[0][j] == "VM ID")
                        try
                        {
                            if (vm.vmid_g != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("vmid_g", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("vmid_g από {0} σε {1}", vm.vmid_g, (string)excel.Rows[row][j]);
                                    vm.vmid_g = (string)excel.Rows[row][j];
                                }
                        }
                        catch { }
                    //vmuuid
                    if ((string)excel.Rows[0][j] == "VM UUID")
                        try
                        {
                            if (vm.vmuuid != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("vmuuid", foreasid, vmid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("vmuuid από {0} σε {1}", vm.vmuuid, (string)excel.Rows[row][j]);
                                    vm.vmuuid = (string)excel.Rows[row][j];
                                }
                        }
                        catch { }
                    //vcenter
                    if ((string)excel.Rows[0][j] == "vCenter UUID")
                        try
                        {
                            if (DateTime.Compare(getlastupdate("vcenter_fk", foreasid, vmid), ReadExcel.date) <= 0)
                            {
                                temp = (string)excel.Rows[row][j];
                                query = "select id from VCenter where description='" + temp + "'";
                                try
                                {
                                    int id = addrecgetid(typeof(VCenter), temp, query);
                                    if (vm.vcenter_fk != id)
                                    {
                                        log += String.Format("vcenter_fk από {0} σε {1}", vm.vcenter_fk, id);
                                        vm.vcenter_fk = id;
                                    }
                                }
                                catch (Exception e)
                                {

                                }
                            }
                        }
                        catch { }
                }
                if(log.Length>0)
                {
                    vm.uid = 7;
                    vm.lastupdate = ReadExcel.date;
                    getBasi().Entry(vm).State=EntityState.Modified;
                    getBasi().SaveChanges();
                }

                
            } catch(Exception e){
                if (log.Length > 0)
                {
                    getBasi().Entry(vm).State = EntityState.Unchanged;
                    try
                    {
                        getBasi().SaveChanges();
                    }
                    catch
                    {
                    }
                }
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "VM:"  +" update:" + exception(e);
            }
            if (log.Length > 0) {
                //string desc = String.Format("με όνομα {0} ", vm.name) + log; 
                int entity = getBasi().EntityTypes.Single(s => s.description.Contains("VMs")).ID;
                int action = getBasi().Actions.Single(s => s.description.Contains("UPDATE")).Actionid;
                addstatus(vm.vmID, entity, log, action);
            }
             
        }



        
        private DateTime getlastupdate(string column, int foreasid, int vmid)
        {
            DateTime lastupdate;
            try
            {
                lastupdate = getBasi().StatusActions.Where(s => s.description.Contains(column) && s.host_table_index_id == vmid && s.entitytypeid_fk == 2).OrderByDescending(x1 => x1.lastupdate).FirstOrDefault().lastupdate.Value;
            }catch(Exception e)
            {
                lastupdate = getBasi().VMs.Where(s => s.vmID == vmid).SingleOrDefault().lastupdate.Value;
            }
            return lastupdate;


        }


        public void add(VM input)
        {

            try
            {
                input.active = 1 == 1;
                input.uid = 7; // CloudTracker.sessionHelpers.userProfile.UserId;
                getBasi().Entry(input).State = EntityState.Added;
                getBasi().SaveChanges();
            }
            catch (Exception e)
            {
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "VM:" + input.name + " add:" + exception(e);
            }
            try{
                int entity = getBasi().EntityTypes.Single(s => s.description.Contains("VMs")).ID;
                int action = getBasi().Actions.Single(s => s.description.Contains("CREATE")).Actionid;
                string description = String.Format("name={0}, typeID_fk={1}, osID_fk={2}", input.name, input.typeID_fk, input.osID_fk);
                addstatus(input.vmID, entity, description, action);
            }
            catch (Exception e) { }            
        }
        
                
        public IEnumerable<OperateSystem> getOs()
        {
            return getBasi().OperateSystems.ToList();
        }

        public IEnumerable<VMType> getVmtype()
        {
            return getBasi().VMTypes.ToList();
            
        }
        
        public string getgcloudcode(int x)
        {
            if (x != 0)
                return getBasi().Foreis.Where(y => y.foreasID == x).SingleOrDefault().gcloud_code;
            else
                return null;
        }
        public IEnumerable<vmConfigStatu> GetConfigStatu()
        {
            return getBasi().vmConfigStatus.ToList();
        }



        public IEnumerable <vmConnectionstate> getconnection()
        {
            return getBasi().vmConnectionstates.ToList();
        }


        public IEnumerable<vmHeartbeat> getheartbeat()
        {
            return getBasi().vmHeartbeats.ToList();
        }

        public IEnumerable<vmCluster> getCluster()
        {
            return getBasi().vmClusters.ToList();
        }



        public IEnumerable<vmHost> getHost()
        {
            return getBasi().vmHosts.ToList();
        }

        public IEnumerable<vmresourcepool> getpool()
        {
            return getBasi().vmresourcepools.ToList();
        }


        public IEnumerable<VCenter> getvcenter()
        {
            return getBasi().VCenters.ToList();
        }



        public IEnumerable<VM> GetAll(int x=0)
        {
            var t1 = (IList<VM>)null;
            if (x != 0)
                t1 = getBasi().VMs.Where(s1 => s1.foreasID_fk == x && s1.active.Equals(1 == 1)).ToList();
            else
                t1 = getBasi().VMs.Where(s1 => s1.active.Equals(1 == 1)).ToList();
            var s = (from tmp in t1
                     select new VM()
                     {
                         active = tmp.active,
                         cpu = tmp.cpu,
                         name = tmp.name,
                         foreasID_fk = tmp.foreasID_fk,
                         osID_fk = tmp.osID_fk,
                         uid = tmp.uid,
                         ram = tmp.ram,
                         vmID = tmp.vmID,
                         lastupdate = tmp.lastupdate,
                         typeID_fk = tmp.typeID_fk,
                         notes = tmp.notes,
                         OperateSystem = tmp.OperateSystem,
                         Forei = tmp.Forei,
                         clustertid_fk=tmp.clustertid_fk,
                         connectstateid_fk=tmp.connectstateid_fk,
                         cpucore=tmp.cpucore,
                         confstatusid_fk=tmp.confstatusid_fk,
                         cpusocket=tmp.cpusocket,
                         DNSname=tmp.DNSname,
                         heartbeatid_fk=tmp.heartbeatid_fk,
                         hostid_fk=tmp.hostid_fk,
                         osconffile=tmp.osconffile,
                         osvmtool=tmp.osvmtool,
                         pathvm=tmp.pathvm,
                         poolid_fk=tmp.poolid_fk,
                         poweron=tmp.poweron,
                         ramconsume=tmp.ramconsume,
                         rammax=tmp.rammax,
                         storageinuse=tmp.storageinuse,
                         storageprovision=tmp.storageprovision,
                         storageunshare =tmp.storageunshare,
                         supported_system_id=tmp.supported_system_id,
                         vcenter_fk=tmp.vcenter_fk,
                         vmid_g=tmp.vmid_g,
                         vmuuid=tmp.vmuuid,
                         
                     });
            return s.ToList();
        }


        

        /*protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            disposed = true;
            // Call base class implementation.
            base.Dispose(disposing);
        }




        ~VMrepo()
        {
            Dispose(true);
        }*/





    }
}