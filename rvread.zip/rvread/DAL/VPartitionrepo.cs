﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;

namespace rvread.DAL
{
    class VPartitionrepo : basi, IAct<GCoud_DiskUtilization>
    {

        public VPartitionrepo(CloudTrackerDevEntities context) : base(context) { }
        public IEnumerable<GCoud_DiskUtilization> GetAll(int x = 0)
        {
            return null;
        }
        public void add(GCoud_DiskUtilization input)
        {
            try
            {

                getBasi().Entry(input).State = EntityState.Added;
                getBasi().SaveChanges();

            }
            catch (Exception e)
            {
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "vpartition:" + input.name + " add:" + exception(e);
            }
        }

        public bool noticlude(string description)
        {
            bool result = true;
            try
            {
                if (getBasi().GCloud_DiskUtilization_ImportExclusions.Where(s=>s.description==description).FirstOrDefault().id>0)
                    result =false;
            }catch(Exception e) {}
            return result;
        }
    }

}
