﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rvread.DAL
{
    class Datastorerepo : basi, IAct<GCloud_DataStoreUtilization>
    {
        public Datastorerepo(CloudTrackerDevEntities context) : base(context) { }
        public IEnumerable<GCloud_DataStoreUtilization> GetAll(int x = 0)
        {
            return null;
        }
        public void add(GCloud_DataStoreUtilization input)
        {
            try
            {
                getBasi().GCloud_DataStoreUtilization.Add(input);
                getBasi().SaveChanges();
            }catch(Exception e){

                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "datastore:" + input.name + " add:" + exception(e);

            }
        }
        public bool notinclude(DateTime date)
        {
            bool result = false;
            GCloud_DataStoreUtilization tmp=null;
            try
            {
                tmp = getBasi().GCloud_DataStoreUtilization.Where(x => x.imera == ReadExcel.date).SingleOrDefault();
                result = true;
            }catch(Exception e){
                result = false;
            }
            return result;


        }



    }
}
