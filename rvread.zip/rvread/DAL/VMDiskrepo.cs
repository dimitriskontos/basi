﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;

namespace rvread.DAL
{
    public class VMDiskrepo : Statusrepo, IAct<VMDisk>
    {
        /*repository για VDisK*/
       // bool disposed = false;
        
        public VMDiskrepo(CloudTrackerDevEntities context) : base(context) { }
        public void add(VMDisk input)
        {
            try
            {
                input.uid = 7;// CloudTracker.sessionHelpers.userProfile.UserId;
                input.lastupdate = ReadExcel.date;
                getBasi().Entry(input).State = EntityState.Added;
                getBasi().SaveChanges();
                

            }
            catch (Exception e)
            {
                //throw new Exception(exception(e));
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "vdisk:" + input.name+ " add:" +exception(e);
            }
            try
            {
                int entity = getBasi().EntityTypes.Single(s => s.description.Contains("Virtual Disks")).ID;
                int action = getBasi().Actions.Single(s => s.description.Contains("CREATE")).Actionid;
                string description = String.Format("name={0}", input.name);
                addstatus(input.vmdiskid, entity, description, action);
            }
            catch {

            }
        }

        public void update(DataTable excel, int vmid, string name, int row)
        {
            string log = "";
            VMDisk vdisk = getBasi().VMDisks.Where(s => s.vmID_fk == vmid && s.name==name ).SingleOrDefault();
            try
            {
                for (int j = 0; j < excel.Columns.Count; j++)
                {

                    //CAPacity
                    if ((string)excel.Rows[0][j] == "Capacity MB")
                        try
                        {
                            if (vdisk.capacity==null || vdisk.capacity != Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", "")))
                                if (DateTime.Compare(getlastupdate("capacity", vdisk.vmdiskid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("cpu από {0} σε {1}", vdisk.capacity, Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", "")));
                                    vdisk.capacity = Convert.ToInt32(((string)excel.Rows[row][j]).Replace(",", ""));
                                }
                        }
                        catch {}
                    //raw
                    else if ((string)excel.Rows[0][j] == "Raw")
                        try
                        {
                            if (vdisk.isRaw==null || (vdisk.isRaw == (1 == 0) && ((string)excel.Rows[row][j]).Contains("True")) || (vdisk.isRaw == (1 == 1) && ((string)excel.Rows[row][j]).Contains("False")))
                                if (DateTime.Compare(getlastupdate("isRaw", vdisk.vmdiskid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("isRaw από {0} σε {1}", vdisk.isRaw, (string)excel.Rows[row][j] == "True" ? 1 == 1 : 1 == 0);
                                    vdisk.isRaw = (string)excel.Rows[row][j] == "True" ? 1 == 1 : 1 == 0;
                                }
                        }
                        catch { }
                    //raw
                    else if ((string)excel.Rows[0][j] == "Thin")
                        try
                        {
                            if (vdisk.isThin==null || (vdisk.isThin == (1 == 0) && ((string)excel.Rows[row][j]).Contains("True")) || (vdisk.isThin == (1 == 1) && ((string)excel.Rows[row][j]).Contains("False")))
                                if (DateTime.Compare(getlastupdate("isThin", vdisk.vmdiskid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("isRaw από {0} σε {1}", vdisk.isThin, (string)excel.Rows[row][j] == "True" ? 1 == 1 : 1 == 0);
                                    vdisk.isThin = (string)excel.Rows[row][j] == "True" ? 1 == 1 : 1 == 0;
                                }
                        }
                        catch { }
                    else if ((string)excel.Rows[0][j] == "Disk Mode")
                    {
                        try
                        {
                            if (DateTime.Compare(getlastupdate("modeid_fk", vdisk.vmdiskid), ReadExcel.date) <= 0)
                            {
                                string temp, query;
                                try
                                {
                                    temp = (string)excel.Rows[row][j];
                                    query = "select id from vmdiskmode where description='" + temp + "'";
                                    int id = addrecgetid(typeof(vmdiskmode), temp, query);
                                    if (vdisk.modeid_fk != id) //an δεν έχει μπει, στον vmConnectionState exception
                                    {
                                        log += String.Format("modeid_fk από {0} σε {1}", vdisk.modeid_fk, id);
                                        vdisk.modeid_fk = id;

                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    }

                    else if ((string)excel.Rows[0][j] == "Controller")
                    {
                        try
                        {
                            if (DateTime.Compare(getlastupdate("contrllerid_fk", vdisk.vmdiskid), ReadExcel.date) <= 0)
                            {
                                string temp, query;
                                try
                                {
                                    temp = (string)excel.Rows[row][j];
                                    query = "select id from vDiskController where description='" + temp + "'";
                                    int id = addrecgetid(typeof(vDiskController), temp, query);
                                    if (vdisk.contrllerid_fk != id) //an δεν έχει μπει, στον vmConnectionState exception
                                    {
                                        log += String.Format("contrllerid_fk από {0} σε {1}", vdisk.contrllerid_fk, id);
                                        vdisk.modeid_fk = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    }
                    else if ((string)excel.Rows[0][j] == "Level")
                    {
                        try
                        {
                            if (DateTime.Compare(getlastupdate("disklevelid_fk", vdisk.vmdiskid), ReadExcel.date) <= 0)
                            {
                                string temp, query;
                                try
                                {
                                    temp = (string)excel.Rows[row][j];
                                    query = "select id from vmDisklevel where description='" + temp + "'";
                                    int id = addrecgetid(typeof(vmDisklevel), temp, query);
                                    if (vdisk.disklevelid_fk != id) //an δεν έχει μπει, στον vmConnectionState exception
                                    {
                                        log += String.Format("disklevelid_fk από {0} σε {1}", vdisk.disklevelid_fk, id);
                                        vdisk.disklevelid_fk = id;
                                    }

                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    }
                    //path
                    else if ((string)excel.Rows[0][j] == "Path")
                        try
                        {
                            if (vdisk.paths != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("paths", vdisk.vmdiskid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("paths από {0} σε {1}", vdisk.paths, (string)excel.Rows[row][j]);
                                    vdisk.paths = (string)excel.Rows[row][j];
                                }
                        }
                        catch { }
                }
                if (log.Length > 0)
                {
                    vdisk.uid = 7;
                    vdisk.lastupdate = ReadExcel.date;
                    getBasi().Entry(vdisk).State = EntityState.Modified;
                    getBasi().SaveChanges();
                    
                }
            }catch(Exception e){
                if (log.Length > 0)
                {
                    getBasi().Entry(vdisk).State = EntityState.Unchanged;
                    try
                    {
                        getBasi().SaveChanges();
                    }
                    catch { }
                }
                if (ReadExcel.longingtext.Length > 0)
                   ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "vdisk:" + vdisk.name + "update:" + exception(e);
                
            }
            if (log.Length > 0)
            {
                //string desc = String.Format("με όνομα {0} ", vdisk.name) + log;
                int entity = getBasi().EntityTypes.Single(s => s.description.Contains("Virtual Disks")).ID;
                int action = getBasi().Actions.Single(s => s.description.Contains("UPDATE")).Actionid;
                addstatus(vdisk.vmdiskid, entity, log, action);
            }
        }
        public VMDisk getvdisk(int vmid, string name)
        {
            VMDisk tmp;
            try{
                tmp= getBasi().VMDisks.Where(s => s.vmID_fk == vmid && s.name == name).SingleOrDefault();
            }
            catch(Exception e){
                tmp = null;
            }
            return tmp;
        }
        private DateTime getlastupdate(string column,  int vmdiskid)
        {
            DateTime lastupdate;
            try
            {
                lastupdate = getBasi().StatusActions.Where(s => s.description.Contains(column) && s.host_table_index_id == vmdiskid && s.entitytypeid_fk == 4).OrderByDescending(x1 => x1.lastupdate).FirstOrDefault().lastupdate.Value;
            }
            catch (Exception e)
            {
                lastupdate = getBasi().VMDisks.Where(s => s.vmdiskid == vmdiskid).SingleOrDefault().lastupdate.Value;
            }
            return lastupdate;
        }
        public IEnumerable<VMDisk> GetAll(int x=0)
        {
            return getBasi().VMDisks.ToList();
        }

        public IEnumerable<VMTier> getTiers()
        {
            return getBasi().VMTiers.ToList();
        }

        public IEnumerable<vmDisklevel> Getdisklevels()
        {
            return getBasi().vmDisklevels.ToList();
        }

        public IEnumerable<vDiskController> GetDiskController()
        {
            return getBasi().vDiskControllers.ToList();
        }
        public IEnumerable<vmdiskmode> getdiskmode()
        {
            return getBasi().vmdiskmodes.ToList();
        }
        public IEnumerable<VMDisk> getvmdisk(int ID = 0)
        {
            if (ID != 0)
                return getBasi().VMDisks.Where(s => (s.vmID_fk == ID)).ToList();
            return getBasi().VMDisks.ToList();
        }
    }



}
