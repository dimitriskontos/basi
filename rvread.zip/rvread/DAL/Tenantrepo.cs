﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace rvread.DAL
{
    public class Tenantrepo : Statusrepo, IAct<Forei>
    {
        //bool disposed = false;
        public Tenantrepo() : base() { }
        public Tenantrepo(CloudTrackerDevEntities context) : base(context) { }
        public IEnumerable<Forei> GetAll(int x = 0)
        {
            if (x == 0)
                return getBasi().Foreis.ToList();
            return getBasi().Foreis.Where(s => s.uid == x).ToList();
        }

        public void add(Forei input)
        {
            try
            {
                input.uid = 7;//CloudTracker.sessionHelpers.userProfile.UserId;
                input.lastupdate = ReadExcel.date;
                getBasi().Foreis.Add(input);
                getBasi().SaveChanges();
            }
            catch (Exception e)
            {
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "Tenant:" + input.description + " add:" + exception(e);
            }
            try
            {
                int entity = getBasi().EntityTypes.Single(s => s.description.Contains("Tenants")).ID;
                int action = getBasi().Actions.Single(s => s.description.Contains("CREATE")).Actionid;
                string description = String.Format(" ID={0}, GCloud code={1}, Σύντομη ονομασία Φορέα={2}, Πλήρες όνομα Φορέα={3}", input.foreasID, input.gcloud_code, input.description, input.foreas_description);
                addstatus(input.foreasID, entity, description, action,input.foreasID);

            }
            catch (Exception e)
            {

            }
        }
        

        

        public int getforeasidbycloud(string cloud)
        {
            int id=0;
            try
            {
                id= getBasi().Foreis.Where(s => s.gcloud_code == cloud).SingleOrDefault().foreasID;
            }
            catch(Exception e)
            {
                throw new Exception(exception(e));
            }
            return id;
        }


        

        public IEnumerable<SupervisingAuthority> GetAuthorities()
        {
            return getBasi().SupervisingAuthorities.ToList();
        }


        public IEnumerable<Status> GetStatuses()
        {
            return getBasi().Status.ToList();
        }

        public IEnumerable<ServiceLevel> GetServiceLevels()
        {
            return getBasi().ServiceLevels.ToList();
        }

        public Forei GetForeasByID(int id)
        {
            return getBasi().Foreis.Single(s => s.foreasID == id);
        }


        public Nullable<DateTime> getaction_start(int x, int id)
        {
            return getBasi().StatusActions.Where(s => s.foreas_id_fk == x && s.status_id_fk == id).SingleOrDefault().action_start;
        }

        




        /*protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            disposed = true;
            // Call base class implementation.
            base.Dispose(disposing);
        }

        ~Tenantrepo()
        {
            Dispose(true);
        }*/

    }
}