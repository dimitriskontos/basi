﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;



namespace rvread.DAL
{
    public class StorageUtilize : basi
    {


        public StorageUtilize(CloudTrackerDevEntities context) : base(context) { }
        public const string UploadUtilDirectory = "C:\\Users\\YLPQ060779\\source\\Workspaces\\Workspace\\rvread\\rvread\\RVtoolFiles";
        

        public void addVolume(GCloud_Volumes input)
        {
            getBasi().GCloud_Volumes.Add(input);
            getBasi().SaveChanges();
        }

        public void addorUpdateVolume(GCloud_Volumes volume)
        {
            GCloud_Volumes f = getBasi().GCloud_Volumes.SingleOrDefault(s => s.description == volume.description);
            if(f==null)
            {
                getBasi().GCloud_Volumes.Add(volume);
            }
            else
            {
                f.capacity = volume.capacity;
                f.hosts = volume.hosts;
                f.online = volume.online;
                f.storage_system = volume.storage_system;
                f.date_added = volume.date_added;
                f.pool = volume.pool;
            }
            getBasi().SaveChanges();


        }

        public void addUtil(GCloud_VolumeUtilization input)
        {
            getBasi().GCloud_VolumeUtilization.Add(input);
            getBasi().SaveChanges();
        }

        public void updateUtil(GCloud_VolumeUtilization input)
        {
            GCloud_VolumeUtilization f = getBasi().GCloud_VolumeUtilization.SingleOrDefault(s => s.volume_id == input.volume_id && s.file_id==input.file_id);
            if (f == null)
                addUtil(input);
            else
            {
                f.free_percent = input.free_percent;
                f.utilised_gb = input.utilised_gb;
                getBasi().SaveChanges();
            }

        }




        public void addReport(GCloud_VolumeUtilReportFile input)
        {
            getBasi().GCloud_VolumeUtilReportFile.Add(input);
            getBasi().SaveChanges();
        }
        public int getvolumeidbydesc(string description)
        {
            int rec = 0;
            try
            {
                rec = getBasi().GCloud_Volumes.Where(s => s.description == description).Single().volume_id;
            }
            catch (Exception e) { }
            return rec;
        }

        public int getidfile()
        {
            int rec = 0;
            try
            {
                rec = getBasi().rvtoolfiles.Where(s => s.imera == ReadExcel.date).Single().fileid;
            }
            catch (Exception e) { }
            return rec;
        }

        public float getcapacity(int id)
        {
            return (float)getBasi().GCloud_Volumes.Where(s => s.volume_id == id).Single().capacity;

        }

        public IEnumerable<GCloud_VolumeUtilization> getDisksbyDate(DateTime imerominia)
        {
            return null;//context.GCloud_VolumeUtilization.Join

        }
        public IEnumerable<GCloud_VolumeUtilReportFile> getfiles()
        {
            return getBasi().GCloud_VolumeUtilReportFile.ToList();
        }
        

        public IEnumerable<GCloud_OverallUsage> getlastoverall()
        {
            DateTime tmp;
            try
            {
                tmp = getBasi().GCloud_OverallUsage.OrderByDescending(s => s.timestamp).FirstOrDefault().timestamp.Value;
                //tmp = context.GCloud_OverallUsage.OrderByDescending(s => s.timestamp.Value.Date).First().timestamp.Value;
                return getBasi().GCloud_OverallUsage.Where(s =>  s.timestamp.Value.Year == tmp.Year && s.timestamp.Value.Month == tmp.Month && s.timestamp.Value.Day == tmp.Day).ToList();
            }
            catch (Exception e) {
                return null;
            }
        }

        public void calculateOverallUsage()
        {
            //construct new entries
            List<GCloud_OverallUsage> _usageList = new List<GCloud_OverallUsage>();
            //new list 
            GCloud_VolumeUtilReportFile rp = new GCloud_VolumeUtilReportFile();
            rp.filename = getBasi().rvtoolfiles.Where(s => s.imera == ReadExcel.date).SingleOrDefault().filename;
            rp.timestamp = ReadExcel.date;
            try {
                getBasi().GCloud_VolumeUtilReportFile.Add(rp);
                getBasi().SaveChanges();
             }
            catch(Exception e){   }
            int fileid = rp.volume_report_file_id;
            GCloud_OverallUsage tmp = new GCloud_OverallUsage();
            tmp.tier = 0;
            tmp.used = 0;
            tmp.avail = 0;
            tmp.total = 0;
            tmp.timestamp = ReadExcel.date;//getBasi().GCloud_VolumeUtilReportFile.Single(s => s.volume_report_file_id == fileID).timestamp;
            tmp.file_id = fileid;
            _usageList.Add(tmp);

            tmp = new GCloud_OverallUsage();
            tmp.tier = 1;
            tmp.used = 0;
            tmp.avail = 0;
            tmp.total = 0;
            tmp.timestamp = ReadExcel.date;//getBasi().GCloud_VolumeUtilReportFile.Single(s => s.volume_report_file_id == fileID).timestamp;
            tmp.file_id = fileid;
            _usageList.Add(tmp);

            tmp = new GCloud_OverallUsage();
            tmp.tier = 2;
            tmp.used = 0;
            tmp.avail = 0;
            tmp.total = 0;
            tmp.timestamp = ReadExcel.date;//getBasi().GCloud_VolumeUtilReportFile.Single(s => s.volume_report_file_id == fileID).timestamp;
            tmp.file_id = fileid;
           _usageList.Add(tmp);
            var volumes = getBasi().GCloud_DataStoreUtilization.Where(x=>x.imera==ReadExcel.date).ToList();
            foreach (GCloud_OverallUsage o in _usageList)
            {
                switch (o.tier)
                {
                  case 0:
                        o.total = volumes.Where(s => s.name.Contains("T0")).Sum(s => s.capacity);
                        //volumeSelector = volumes.Where(s => s.pool.StartsWith("T0")).Select(p => p.volume_id).ToList();
                        o.used = volumes.Where(s => s.name.Contains("T0")).Sum(s => s.inuse);
                        o.avail = o.total - o.used;
                       break;
                  case 1:
                        o.total = volumes.Where(s => s.name.Contains("T1")).Sum(s => s.capacity);
                        //volumeSelector = volumes.Where(s => s.pool.StartsWith("T0")).Select(p => p.volume_id).ToList();
                        o.used = volumes.Where(s => s.name.Contains("T1")).Sum(s => s.inuse);
                        o.avail = o.total - o.used;
                        break;
                  case 2:
                        o.total = volumes.Where(s => s.name.Contains("T2")).Sum(s => s.capacity);
                        //volumeSelector = volumes.Where(s => s.pool.StartsWith("T0")).Select(p => p.volume_id).ToList();
                        o.used = volumes.Where(s => s.name.Contains("T2")).Sum(s => s.inuse);
                        o.avail = o.total - o.used;
                        break;
                }
                getBasi().GCloud_OverallUsage.Add(o);
                getBasi().SaveChanges();
            }

        }
        

    }
}