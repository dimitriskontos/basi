﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rvread.DAL
{
    public interface IAct<T>
    {
        void add(T input);
        IEnumerable<T> GetAll(int x=0);
        
       
    }
}
