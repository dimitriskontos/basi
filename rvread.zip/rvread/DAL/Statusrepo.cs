﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using System.Linq.Expressions;


namespace rvread.DAL
{
    //Προσθέτει ενημερώσεις ιστορικού
    public class Statusrepo : basi
    {
        public Statusrepo() : base() { }
        public Statusrepo(CloudTrackerDevEntities context) : base(context) { }
        //bool disposed = false;






        public void addstatus(int id, int entityid, string description, int action, int foreasid = 0)
        {
            StatusAction a = new StatusAction();
            try
            {
                a.uid = 7;// CloudTracker.sessionHelpers.userProfile.UserId;
                a.completed = true;
                a.host_table_index_id = id;
                a.entitytypeid_fk = entityid;
                a.action_start = ReadExcel.date;
                a.action_end = ReadExcel.date; 
                a.lastupdate = ReadExcel.date;
                a.action_estimated_end = ReadExcel.date;
                a.description = description;
                a.fordisplay = false;
                a.actionid_fk = action;
                a.foreas_id_fk = foreasid;
                getBasi().Entry(a).State = EntityState.Added;
                getBasi().SaveChanges();
            }catch(Exception e)
            {
                //throw new Exception(exception(e));
            }
        }

        

        /*~Statusrepo()
        {
            Dispose(true);
        }




        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            disposed = true;
            // Call base class implementation.
            base.Dispose(disposing);
        }
        */


    }
}