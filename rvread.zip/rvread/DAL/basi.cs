﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Data.Entity.Infrastructure;
using System.Data;
namespace rvread.DAL
{
    public class basi 
    {
        private CloudTrackerDevEntities context;
        public basi(CloudTrackerDevEntities context)
        {
            this.context = context;
        }
        public basi()
        {
            this.context = new CloudTrackerDevEntities();
        }
        public CloudTrackerDevEntities getBasi()
        {
            return context;
        }

        public IEnumerable<object> getforeis()
        {
            return getBasi().Foreis.GroupJoin(getBasi().SupervisingAuthorities, f => f.authorityID, sp => sp.sup_foreas_id, (f, sp) => new { id = f.foreasID, onoma = f.foreas_description + "-" + f.description }).ToList();
        }

        public string name(int x)
        {
            return getBasi().Foreis.GroupJoin(getBasi().SupervisingAuthorities, f => f.authorityID, sp => sp.sup_foreas_id, (f, sp) => new { id = f.foreasID, onoma = f.foreas_description + "-" + f.description }).Single(s => s.id == x).onoma;
        }

        public int getvmid(string name)
        {
            int result = -1;
            try
            {
                result = getBasi().VMs.Where(s => s.name == name).Single().vmID;
            }catch(Exception e)
            {  
            }
            return result;
            
        }
        
        public VMNIC GetVMNIC(int vmid, int vlanid)
        {
            return getBasi().VMNICs.Where(S => S.vlanID_fk == vlanid && S.vmID_fk == vmid).SingleOrDefault();
        }



        public int getvlanid(string name)
        {
            return getBasi().vlans.Where(s => s.name == name).Single().vlanID;
        }

        public int addrecgetid(Type type, string desc, string query)
        {
            var result = (dynamic)null;
            int id;
            try
            {
                id = getBasi().Database.SqlQuery<int>(query).FirstOrDefault();
            }
            catch {
                id = 0;
            }
            if (id <= 0)
            {
                result = Activator.CreateInstance(type);
                result.description = desc;
                getBasi().Set(type).Add(result);
                getBasi().SaveChanges();
                id = getBasi().Database.SqlQuery<int>(query).FirstOrDefault();
            }
            return id;
        }


        public string exception(Exception s)
        {

            string message = "";

            if (s is DbEntityValidationException)
            {
                DbEntityValidationException e = (DbEntityValidationException)s;
                foreach (var eve in e.EntityValidationErrors)
                {
                    foreach (var ve in eve.ValidationErrors)
                    {
                        message += ve.ErrorMessage + ",";
                    }
                    if (message.Length > 0)
                        message = message.Substring(0, message.Length - 1);
                }
            }else if(s is SqlException)
            {
                SqlException e = (SqlException)s;
                for (int i = 0; i < e.Errors.Count; i++)
                {
                    var errorNum = e.Errors[i].Number;
                    message += e.Errors[i].Number + ":" + e.Errors[i].Message + ",";

                }
                if (message.Length > 0)
                    message = message.Substring(0, message.Length - 1);
            }
            else if (s is DbUpdateException)
            {
                DbUpdateException e = (DbUpdateException)s;
                var inner = GetInners(e).Last();
                message += inner.Message;
            }
            else
            {
                message = "Λάθος:" +s.Message;
            }

            return message;

        }

        private IEnumerable<Exception> GetInners(Exception ex)
        {
            for (Exception e = ex; e != null; e = e.InnerException)
                yield return e;
        }


        

    }
}