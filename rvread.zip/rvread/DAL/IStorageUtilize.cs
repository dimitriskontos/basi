﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rvread.DAL
{
    interface IStorageUtilize
    {
        void addVolume(GCloud_Volumes input);
        void addorUpdateVolume(GCloud_Volumes volume);
        void addUtil(GCloud_VolumeUtilization input);
        void addfirewall(tenant_firewall input);
        void updatefirewall(tenant_firewall input);
        //void getfirewallbyID
        void updateUtil(GCloud_VolumeUtilization input);
        void addReport(GCloud_VolumeUtilReportFile input);
        void deletefile(int id);
        IEnumerable<GCloud_VolumeUtilReportFile> getfiles();
        IEnumerable<GCloud_OverallUsage> getlastoverall();
        int getvolumeidbydesc(string description);
        int getidfile(string file);
        float getcapacity(int id);
        IEnumerable<GCloud_VolumeUtilization> getDisksbyDate(DateTime imerominia);

        void calculateOverallUsage(int fileID,string neo);
    }
}
