﻿using System.Collections.Generic;


namespace rvread.DAL
{
    public abstract class Act<T> : basi, IAct<T>
    {
        //public Act(CloudTrackEntities context) : base(context) { }
        
        public Act() : base() { }
        public Act(CloudTrackerDevEntities context) : base(context) { }
        public virtual void add(T input) { }
        public virtual IEnumerable<T> GetAll(int x=0) { return null; }
        
        public virtual void del(T model) { }
        public virtual void update(T model) { }

    }
}