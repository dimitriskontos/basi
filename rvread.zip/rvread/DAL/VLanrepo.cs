﻿using System.Collections.Generic;
using System.Linq;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
namespace rvread.DAL
{
    public class VLanrepo : Statusrepo, IAct<vlan>
    {
        //bool disposed = false;
        
        public VLanrepo(CloudTrackerDevEntities context) : base(context) { }
        public void add(vlan input)
        {
            try
            {
                input.active = 1 == 1;
                input.uid = 7;
                input.lastupdate = ReadExcel.date;
                getBasi().Entry(input).State = EntityState.Added;
                getBasi().SaveChanges();
            }
            catch (Exception e)
            {
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "VLAN:" + input.name + " add:" + exception(e);
            }
            
            try
            {
                int entity = getBasi().EntityTypes.Single(s => s.description.Contains("VLANs")).ID;
                int action = getBasi().Actions.Single(s => s.description.Contains("CREATE")).Actionid;
                string description = String.Format(" vlanID={0}, NAME={1}, foreasID_fk={2}", input.vlanID, input.name, input.foreasID_fk);
                addstatus(input.vlanID, entity, description, action);
            }
            catch(Exception e)
            {      
            }
            
            
        }

        public vlan getvlan(string name)
        {
            vlan tmp;
            try
            {
                int id = Convert.ToInt32(name.Substring(name.Length - 4, 4));
                tmp = getBasi().vlans.Where(s => s.vlanID == id).SingleOrDefault();
            }catch(Exception e){
                tmp = null;
            }
            return tmp;
        }


        

        public IEnumerable<vlan> GetAll(int x=0)
        {
            if (x == 0)
                return getBasi().vlans.Where(s => s.active.Equals(1 == 1)).ToList();
            else
                return getBasi().vlans.Where(s => s.foreasID_fk == x && s.active.Equals(1 == 1)).ToList();
            
        }

        public IEnumerable<tenant_firewall> firewall(int x=0)
        {
            var vlans = GetAll(x);
            IEnumerable<tenant_firewall> model1 = getBasi().tenant_firewall.Where(s => (s.srcintf == "any" && s.srcaddr == "all") || (s.dstintf == "any" && s.dstaddr == "all") || (s.srcintf == "outside_tenants" && s.srcaddr == "all") || (s.dstintf == "outside_tenants" && s.dstaddr == "all")).ToList();
            if (vlans != null)//an o tennant exei vlan
            {
                IEnumerable<string> vlans_s = vlans.Select(t => Convert.ToString(t.vlanID));
                var model2 = getBasi().tenant_firewall.Where(fire => vlans_s.Any(vl => fire.srcintf.Contains(vl)) || vlans_s.Any(vl1 => fire.dstintf.Contains(vl1))).ToList();
                model1 = model1.Union(model2).Distinct();
            }
            return model1;

        }
        
    }
}