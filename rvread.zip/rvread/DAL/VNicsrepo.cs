﻿using System.Collections.Generic;
using System.Linq;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace rvread.DAL
{
    public class VNicsrepo : Statusrepo, IAct<VMNIC>
    {

        
        public VNicsrepo(CloudTrackerDevEntities context) : base(context) { }
        public void add(VMNIC input)
        {
            try
            {
                input.lastupdate = ReadExcel.date;
                input.uid = 7;
                //bool disposed = false;
                getBasi().Entry(input).State = EntityState.Added;
                getBasi().SaveChanges();

            }
            catch (Exception e)
            {
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "vnics:" + input.IP + " add:" + exception(e);
                //throw new Exception(exception(e));
            }
            try
            {
                int entity = getBasi().EntityTypes.Single(s => s.description.Contains("VNICs")).ID;
                int action = getBasi().Actions.Single(s => s.description.Contains("CREATE")).Actionid;
                string description = String.Format("IP={1},vlan={2}",input.IP, input.IP, input.vlanID_fk);
                int vnicid = getBasi().VMNICs.Where(s => s.IP == input.IP && s.vlanID_fk == input.vlanID_fk && s.vmID_fk == input.vmID_fk).SingleOrDefault().VMNICsid;
                //int foreasid = context.Foreis.Join(context.VMs, s => s.foreasID, s1 => s1.foreasID_fk, (s, s1) => new { foreasID = s.foreasID, VMid = s1.vmID }).Join(context.VMNICs, s2 => s2.VMid, s3 => s3.vmID_fk, (s2, s3) => new { id = s2.foreasID }).Single().id;
                //int foreasid = getBasi().VMs.Where(s => s.vmID == input.vmID_fk).SingleOrDefault().foreasID_fk.Value;
                addstatus(input.VMNICsid, entity, description, action);
            }
            catch { }
        }

        public void update(DataTable excel, int row,int vlanid, int vmid)
        {
            VMNIC vmnic = getBasi().VMNICs.Where(x => x.vlanID_fk == vlanid && x.vmID_fk == vmid).SingleOrDefault();
            string changelog = "";
            string log = "";
            try
            {
                for (int j = 0; j < excel.Columns.Count; j++)
                {
                    //connected
                    if ((string)excel.Rows[0][j] == "Connected")
                        try
                        {
                            if ((vmnic.connected == (1 == 0) && ((string)excel.Rows[row][j]).Contains("True")) || (vmnic.connected == (1 == 1) && ((string)excel.Rows[row][j]).Contains("False")))
                                if (DateTime.Compare(getlastupdate("connected", vmnic.VMNICsid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("isRaw από {0} σε {1}", vmnic.connected, (string)excel.Rows[row][j] == "True" ? 1 == 1 : 1 == 0);
                                    vmnic.connected = (string)excel.Rows[row][j] == "True" ? 1 == 1 : 1 == 0;
                                }
                        }
                        catch { }
                    //type
                    if ((string)excel.Rows[0][j] == "Type")
                    {
                        try
                        {
                            if (DateTime.Compare(getlastupdate("typeid_fk", vmnic.VMNICsid), ReadExcel.date) <= 0)
                            {
                                string temp, query;
                                try
                                {
                                    temp = (string)excel.Rows[row][j];
                                    query = "select id from vnickType where description='" + temp + "'";
                                    int id = addrecgetid(typeof(vnickType), temp, query);
                                    if (vmnic.typeid_fk != id) //an δεν έχει μπει 
                                    {
                                        log += String.Format("typeid_fk από {0} σε {1}", vmnic.typeid_fk, id);
                                        vmnic.typeid_fk = id;

                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    }

                    if ((string)excel.Rows[0][j] == "Adapter")
                    {
                        try
                        {
                            if (DateTime.Compare(getlastupdate("adapterid_fk", vmnic.VMNICsid), ReadExcel.date) <= 0)
                            {
                                string temp, query;
                                try
                                {
                                    temp = (string)excel.Rows[row][j];
                                    query = "select id from vnickAdapter where description='" + temp + "'";
                                    int id = addrecgetid(typeof(vnickAdapter), temp, query);
                                    if (vmnic.adapterid_fk != id) //an δεν έχει μπει, στον vmConnectionState exception
                                    {
                                        log += String.Format("adapterid_fk από {0} σε {1}", vmnic.adapterid_fk, id);
                                        vmnic.adapterid_fk = id;
                                    }
                                }
                                catch (Exception e) { }
                            }
                        }
                        catch { }
                    }
                    //path
                    if ((string)excel.Rows[0][j] == "IP Address")
                        try
                        {
                            if (vmnic.IP != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("IP", vmnic.VMNICsid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("IP από {0} σε {1}", vmnic.IP, (string)excel.Rows[row][j]);
                                    vmnic.IP = (string)excel.Rows[row][j];
                                }
                        }
                        catch { }

                    //MAC
                    if ((string)excel.Rows[0][j] == "MAC Address")
                        try
                        {
                            if (vmnic.MAC != (string)excel.Rows[row][j])
                                if (DateTime.Compare(getlastupdate("MAC", vmnic.VMNICsid), ReadExcel.date) <= 0)
                                {
                                    log += String.Format("MAC από {0} σε {1}", vmnic.MAC, (string)excel.Rows[row][j]);
                                    vmnic.MAC = (string)excel.Rows[row][j];
                                }
                        }
                        catch { }
                }
                if (log.Length > 0)
                {
                    vmnic.uid = 7; //CloudTracker.sessionHelpers.userProfile.UserId;
                    vmnic.lastupdate = ReadExcel.date;
                    getBasi().Entry(vmnic).State = EntityState.Modified;
                    getBasi().SaveChanges();
                }
            }
            catch (Exception e)
            {
                getBasi().Entry(vmnic).State = EntityState.Unchanged;
                try
                {
                    getBasi().SaveChanges();
                }
                catch { }
                //throw new Exception(exception(e));
                if (ReadExcel.longingtext.Length > 0)
                    ReadExcel.longingtext += ", ";
                ReadExcel.longingtext += "VNICs:" + " update:" + exception(e);

            }
            try
            {
                if (changelog.Length > 0)
                {
                    int entity = getBasi().EntityTypes.Single(s => s.description.Contains("VNICs")).ID;
                    int action = getBasi().Actions.Single(s => s.description.Contains("UPDATE")).Actionid;
                    //int foreasid = getBasi().Foreis.Join(getBasi().VMs, s => s.foreasID, s1 => s1.foreasID_fk, (s, s1) => new { foreasID = s.foreasID, VMid = s1.vmID }).Join(getBasi().VMNICs, s2 => s2.VMid, s3 => s3.vmID_fk, (s2, s3) => new { id = s2.foreasID, vnicsid = s3.VMNICsid }).Single(p => p.vnicsid == vnic.VMNICsid).id;
                    addstatus(vmnic.VMNICsid, entity, log, action);
                }
            }
            catch (Exception e)
            {

            }
        }



        private DateTime getlastupdate(string column, int vnicsid)
        {
            DateTime lastupdate;
            try
            {
                lastupdate = getBasi().StatusActions.Where(s => s.description.Contains(column) && s.host_table_index_id == vnicsid && s.entitytypeid_fk == 5).OrderByDescending(x1 => x1.lastupdate).FirstOrDefault().lastupdate.Value;
            }
            catch (Exception e)
            {
                lastupdate = getBasi().VMNICs.Where(s => s.VMNICsid == vnicsid).SingleOrDefault().lastupdate.Value;
            }
            return lastupdate;


        }



        

        public IEnumerable<VMNIC> GetAll(int x=0)
        {
            if (x != 0)
                return getBasi().VMNICs.Where(s => (s.vmID_fk == x)).ToList();
            return getBasi().VMNICs.ToList();
            
        }

        public  IEnumerable<object> getvlan(int tenant)
        {
            int? tennantID = 0;
            tennantID = getBasi().VMs.Single(s => s.vmID == tenant).foreasID_fk;
            return getBasi().vlans.Where(s => s.foreasID_fk == tennantID).Select(s => new { id = s.vlanID, onoma = s.name + " " + s.vlanID }).ToList();
        }

        public IEnumerable<vnickType> getnicktype()
        {
            return getBasi().vnickTypes.ToList();
        }

        public IEnumerable<vnickAdapter> getadapter()
        {
            return getBasi().vnickAdapters.ToList();
        }

        /*protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            disposed = true;
            // Call base class implementation.
            base.Dispose(disposing);
        }


        ~VNicsrepo()
        {
            Dispose(true);
        }*/




    }
}