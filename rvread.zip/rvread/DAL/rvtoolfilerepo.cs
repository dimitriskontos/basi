﻿using System;
using System.Linq;


namespace rvread.DAL
{
    class rvtoolfilerepo : IDisposable
    {
        private CloudTrackerDevEntities context;
        public rvtoolfilerepo()
        {
            context = new CloudTrackerDevEntities();
        }
        public rvtoolfilerepo(CloudTrackerDevEntities con)
        {
            this.context = con;
        }
        bool disposed = false;
        public bool notinclude(string file)
        {

            try
            {
                rvtoolfile tmp = context.rvtoolfiles.Where(S => S.filename.Contains(file)).Single();
                return false;
            }
            catch (Exception e)
            {
                return true;
            }
        }
        public void addfile(rvtoolfile rv)
        {

            try{ 
                context.rvtoolfiles.Add(rv);
                context.SaveChanges();
            }catch(Exception e){
                //throw new Exception("Πρόβλημα εισαγωγής αρχείου " + rv.filename);
            }
        }

        public bool ispalio()
        {
            bool result = true;
            Nullable<System.DateTime> last;
            try
            {
                last = context.rvtoolfiles.OrderByDescending(x1 => x1.imera).FirstOrDefault().imera;
                if (DateTime.Compare(ReadExcel.date, last.Value) > 0)
                    result=false;
            }
            catch (Exception e){
                result = false;
            }
            return result;
        }

        public void update()
        {
            rvtoolfile tmp = context.rvtoolfiles.Where(s => s.imera.Value == ReadExcel.date).SingleOrDefault();
            tmp.logginttext = ReadExcel.longingtext;
            context.SaveChanges();
        }



        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
                context.Dispose();
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
    