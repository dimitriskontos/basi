﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Data.OleDb;
using System.Data;
using rvread.DAL;

namespace rvread
{
    class epexergasia
    {
        private ReadExcel excel;
        private CloudTrackerDevEntities context;
        public epexergasia(ReadExcel excel, CloudTrackerDevEntities context)
        {
            this.excel = excel;
            this.context = context;
        }
        public void AddTenant()
        {
            string gcloud;
            Forei tmp = null;
            int id = 0;
            Tenantrepo tm;
            //bres kolones network
            int colnetwork = 0;
            int colvlan = 0;

            for (int i = 0; i < excel.tables[4].Columns.Count; i++)
                if (((string)excel.tables[4].Rows[0][i])=="Network")
                {
                    colvlan = i;
                    break;
                }

            for (int i=0; i < excel.tables[0].Columns.Count;i++)
               if (((string)excel.tables[0].Rows[0][i]).Contains("Network"))
                   colnetwork++;
            
            int[] network = new int[colnetwork];
            int j = 0;
            for (int i = 0; i < excel.tables[0].Columns.Count; i++)
                if (((string)excel.tables[0].Rows[0][i]).Contains("Network"))
                    network[j++] = i;

            for (int i = 1; i < excel.tables[0].Rows.Count; i++)
            {
                if ((!(excel.tables[0].Rows[i][0] is DBNull)) && ((string)excel.tables[0].Rows[i][0]).StartsWith("0"))
                {
                    gcloud = ((string)excel.tables[0].Rows[i][0]).Substring(0, 3);
                    tm = new Tenantrepo(context);
                    try{
                        id = tm.getforeasidbycloud(gcloud);
                    }
                    catch{
                        id = 0;
                    }
                    if (id <= 0)//καινούριος TENANT
                    {
                        tmp = new Forei();
                        tmp.gcloud_code = gcloud;
                        tmp.statusID = 4;
                        tmp.description = "enimer_apo_rvtool";
                        tmp.lastupdate = ReadExcel.date;
                        tm.add(tmp);
                        id = tm.getforeasidbycloud(gcloud);
                    }
                    updateVM(id, i);
                    updateVDisk(i);
                    updateVPartition(i);
                    updateVLan(network, id, i);
                    updateVNic(network, i, colvlan);

                }
            }
            UpdateDatastore();
            StorageUtilize st = new StorageUtilize(context);
            st.calculateOverallUsage();
            return;
        }






        private void UpdateDatastore()
        {

            GCloud_DataStoreUtilization tmp;
            Datastorerepo rp = new Datastorerepo(context);
            if(rp.notinclude(ReadExcel.date))
                for (int j = 1; j < excel.tables[5].Rows.Count; j++)
                {
                if ((!(excel.tables[5].Rows[j][0] is DBNull)) && ((string)excel.tables[5].Rows[j][0]).StartsWith("V7K"))
                {
                    tmp = new GCloud_DataStoreUtilization();

                    for (int i = 0; i < excel.tables[5].Columns.Count; i++)
                    {
                        if ((string)excel.tables[5].Rows[0][i] == "Name")
                            try
                            {
                                tmp.name = (string)excel.tables[5].Rows[j][i];
                            }
                            catch { }
                        else if ((string)excel.tables[5].Rows[0][i] == "# Hosts")
                            try
                            {
                                tmp.hosts = Convert.ToInt32(((string)excel.tables[5].Rows[j][i]).Replace(",", ""));
                            }
                            catch { }
                        else if (((string)excel.tables[5].Rows[0][i] == "Capacity MB"))
                            try
                            {
                                tmp.capacity = Convert.ToInt32(((string)excel.tables[5].Rows[j][i]).Replace(",", ""));
                            }
                            catch { }
                        else if (((string)excel.tables[5].Rows[0][i] == "Provisioned MB"))
                            try
                            {
                                tmp.provision = Convert.ToInt32(((string)excel.tables[5].Rows[j][i]).Replace(",", ""));
                            }
                            catch { }
                        else if (((string)excel.tables[5].Rows[0][i] == "In Use MB"))
                            try
                            {
                                tmp.inuse = Convert.ToInt32(((string)excel.tables[5].Rows[j][i]).Replace(",", ""));
                            }
                            catch { }
                        else if (((string)excel.tables[5].Rows[0][i] == "Free MB"))
                            try
                            {
                                tmp.free = Convert.ToInt32(((string)excel.tables[5].Rows[j][i]).Replace(",", ""));
                            }
                            catch { }
                    }
                    tmp.imera = ReadExcel.date;
                    rp.add(tmp);
                }
            }


        }


        private void updateVPartition(int row)
        {
            GCoud_DiskUtilization tmp = null;
            int k=row;
            string namevm = (string)excel.tables[0].Rows[row][0];
            VPartitionrepo pr = new VPartitionrepo(context);
            try
            {
                while (!((string)excel.tables[6].Rows[k][0] == namevm))
                    k++;
            }catch(Exception e)
            {
                return;
            }
            int vmid = pr.getvmid(namevm);
            while(((string)excel.tables[6].Rows[k][0] == namevm))
            {
                tmp = new GCoud_DiskUtilization();
                tmp.vmid = vmid;
                for (int i=0; i< excel.tables[6].Columns.Count;i++)
                {
                    if ((string)excel.tables[6].Rows[0][i] == "Disk")
                        tmp.name= (string)excel.tables[6].Rows[k][i];
                    else if (((string)excel.tables[6].Rows[0][i] == "Capacity MB"))
                        tmp.capacity = Convert.ToInt32(((string)excel.tables[6].Rows[k][i]).Replace(",", ""));
                    else if (((string)excel.tables[6].Rows[0][i] == "Free MB"))
                        tmp.free = Convert.ToInt32(((string)excel.tables[6].Rows[k][i]).Replace(",", ""));
                }
                tmp.imera = ReadExcel.date;
                if (pr.noticlude(tmp.name))
                    pr.add(tmp);    
                k++;
            }
        }









        private void updateVNic(int[] network,int row, int colvlan)
        {
            VMNIC tmpvnick = null;
            //όνοma vm
            string namevm = (string)excel.tables[0].Rows[row][0];
            int k = row;
            VNicsrepo vnic = new VNicsrepo(context);
            while (!((string)excel.tables[4].Rows[k][0] == namevm))
                k++;
            int vmid = vnic.getvmid(namevm);//context.VMs.Where(s => s.name == namevm).Single().vmID;
            //gia osa vlan εχουμε
            string vlaname;
            int vlanid;
            for (int i = 0; i < network.Length; i++)
            {
                vlaname = (string)excel.tables[4].Rows[k][colvlan];
                vlanid = vnic.getvlanid(vlaname);//context.vlans.Where(s => s.name == vlaname).Single().vlanID;
                tmpvnick = vnic.GetVMNIC(vmid, vlanid);//context.VMNICs.Where(S => S.vlanID_fk == vlanid && S.vmID_fk == vmid).SingleOrDefault();
                if (tmpvnick == null)
                {
                    tmpvnick = new VMNIC();
                    tmpvnick.vlanID_fk = vlanid;
                    tmpvnick.vmID_fk = vmid;
                    vnic.add(tmpvnick);
                }
                vnic.update(excel.tables[4], k,vlanid, vmid);
                if ((string)excel.tables[4].Rows[k+1][0] != namevm) 
                    break;
                k++;
            }
        }






        private void updateVLan(int[] network, int foreasid, int row)
        {
            vlan tmpvlan = null;
            VLanrepo vl = new VLanrepo(context);
            string name;
            for (int i=0;i<network.Length;i++)
            {
                if(!(excel.tables[0].Rows[row][network[i]] is DBNull))
                {
                    name = (string)excel.tables[0].Rows[row][network[i]];
                    try{
                        tmpvlan = vl.getvlan(name);
                    }
                    catch { }
                    if (tmpvlan == null)
                    {

                        tmpvlan = new vlan();
                        tmpvlan.vlanID = Convert.ToInt32(name.Substring(name.Length - 4, 4));
                        tmpvlan.foreasID_fk = foreasid;
                        tmpvlan.name = name;
                        vl.add(tmpvlan);
                    }
                }
            }
        }





        private void updateVDisk(int row)
        {
            VMDisk tmpVDisk = null;
            string namevm = (string)excel.tables[0].Rows[row][0];
            string diskname="";
            int count = 0;
            int coldiskname = 0;
            //Πάρε αριθμό δίσκων
            for (int i = 0; i < excel.tables[0].Columns.Count; i++)
            {
                if ((string)excel.tables[0].Rows[0][i] == "Disks")
                {
                    count = Convert.ToInt32((string)excel.tables[0].Rows[row][i]);
                    break;
                }
            }
            int k = row;
            while (!((string)excel.tables[3].Rows[k][0] == namevm))
                k++;
            VMDiskrepo vdiskrepo= new VMDiskrepo(context);
            int vmid = vdiskrepo.getvmid(namevm);
            for (int z = 1; z < excel.tables[3].Columns.Count; z++)
                if (((string)excel.tables[3].Rows[0][z])=="Disk")
                {
                    coldiskname =z;
                    break;
                }
            for (int j = k; j < k + count; j++)
            {

                diskname = ((string)excel.tables[3].Rows[j][coldiskname]).TrimEnd();
                tmpVDisk = vdiskrepo.getvdisk(vmid, diskname); //context.VMDisks.Where(s => s.vmID_fk == vmid && s.name == diskname).SingleOrDefault();
                if (tmpVDisk == null){
                    tmpVDisk = new VMDisk();
                    tmpVDisk.name = diskname;
                    tmpVDisk.vmID_fk = vmid;
                    vdiskrepo.add(tmpVDisk);
                }
                vdiskrepo.update(excel.tables[3], tmpVDisk.vmID_fk, tmpVDisk.name,j);
            }
        }



        private void updateVM(int foreasid, int i)
        {
            VM tmpVM = null;
            string name = (string)excel.tables[0].Rows[i][0];
            VMrepo vm = new VMrepo(context);
            try{
                tmpVM = vm.getvmbyname(name);
            }catch(Exception e){
                tmpVM = null;
            }
            if (tmpVM == null) {
                tmpVM = new VM();
                tmpVM.lastupdate = ReadExcel.date;
                //foreasid
                tmpVM.foreasID_fk = foreasid;
                //όνομα
                name = (string)excel.tables[0].Rows[i][0];
                tmpVM.name = name;
                //τύπος vm
                if (((string)excel.tables[0].Rows[i][0]).ToUpper().Contains("CLONE"))
                    tmpVM.typeID_fk = 3;
                else if (((string)excel.tables[0].Rows[i][0]).ToUpper().Contains("MIGRATION"))
                    tmpVM.typeID_fk = 2;
                else
                    tmpVM.typeID_fk = 1;
                //λειτουργικό
                for (int m = 1; m < excel.tables[0].Columns.Count; m++)
                {
                    if ((string)excel.tables[0].Rows[0][m] == "OS according to the VMware Tools")
                    {
                        string temp = (string)excel.tables[0].Rows[i][m];
                        string query = "select osID from OperateSystem where description='" + temp + "'";
                        try
                        {
                            tmpVM.osID_fk = vm.addrecgetid(typeof(OperateSystem), temp, query);
                        }
                        catch (Exception e) { }

                    }
                }
               
                tmpVM.active = (1 == 1);
                try{
                    vm.add(tmpVM);
                }catch(Exception e){
                    //ενημέρωση log
                }
            }
            //ενημέρωση vm
            try{
                vm.update(excel.tables[0], tmpVM.foreasID_fk.Value, tmpVM.vmID, i);
            }
            catch{
                //ενημέρωση log
            }
        }



        









    }














        





   
}
