﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Data.OleDb;
using System.Data;

using System.Text.RegularExpressions;



namespace rvread
{
    class ReadExcel
    {
        public static DateTime date { get; set; }
        public static bool isPalio;
        public string filename { get; set; }
        private DataTable[] _tables;
        public DataTable[] tables  { get { if (_tables != null) return _tables;  else return readfile(); } }
        public static string longingtext = "";
        
        private DataTable[] readfile()
        {
            
            this.filename = getfile();
            string directory = DAL.StorageUtilize.UploadUtilDirectory;
            string s = this.filename; //System.Web.HttpContext.Current.Request.MapPath(filepath);
            string cons;
            OleDbConnection econ;
            var query = "";
            OleDbDataAdapter objAdapter1;
            OleDbCommand Ecom;
            DataSet ds;
            System.Data.DataTable dtable;
            //var k = filename.Where(Char.IsDigit);
            DataTable[] dtables = null;
            /*Πάρε όνομα φύλου*/
            /*Dhmioyrgia αρχείου schema.ini γραψιμο πληροφοριών*/
            try
            {
                FileInfo file = new FileInfo(s);
                FileStream filestr = new FileStream(directory + "\\schema.ini", FileMode.Create, FileAccess.Write);
                StreamWriter writer = new StreamWriter(filestr, System.Text.Encoding.Default);
                writer.WriteLine("[" + filename + "]");
                writer.WriteLine("ColNameHeader = False");
                writer.WriteLine("CharacterSet=ANSI");
                cons = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=NO;IMEX=1""", s);
                econ = new OleDbConnection(cons);
                econ.Open();
                //econ.ConnectionString = cons;
                dtable = econ.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtable.Rows.Count];
                int i = 0;
                dtables = new DataTable[dtable.Rows.Count];
                foreach (DataRow r in dtable.Rows)
                {
                    excelSheets[i] = r["TABLE_NAME"].ToString();
                    query = "SELECT * FROM [" + excelSheets[i] + "]";
                    Ecom = new OleDbCommand(query, econ);
                    objAdapter1 = new OleDbDataAdapter();
                    objAdapter1.SelectCommand = Ecom;
                    ds = new DataSet();
                    objAdapter1.Fill(ds);
                    if (r["TABLE_NAME"].ToString().Contains("vInfo"))
                        dtables[0] = ds.Tables[0];
                    else if ((r["TABLE_NAME"].ToString().Contains("vCPU")))
                        dtables[1] = ds.Tables[0];
                    else if ((r["TABLE_NAME"].ToString().Contains("vMemory")))
                        dtables[2] = ds.Tables[0];
                    else if ((r["TABLE_NAME"].ToString().Contains("vDisk")))
                        dtables[3] = ds.Tables[0];
                    else if ((r["TABLE_NAME"].ToString().Contains("vNetwork")))
                        dtables[4] = ds.Tables[0];
                    else if ((r["TABLE_NAME"].ToString().Contains("vDatastore")))
                        dtables[5] = ds.Tables[0];
                    else if ((r["TABLE_NAME"].ToString().Contains("vPartition")))
                        dtables[6] = ds.Tables[0];
                    i += 1;
                }
                econ.Close();
            }catch(Exception e)
            {
                this.filename = null;
            }
            this._tables = dtables;
            return dtables; 
            
        }

        

        private string getfile()
        {
            DAL.rvtoolfilerepo rv = new DAL.rvtoolfilerepo();
            string[] arr = Directory.GetFiles(Path.GetFullPath(DAL.StorageUtilize.UploadUtilDirectory), "*.xls");
            foreach (string file in arr)
            {
                if (rv.notinclude(file))
                {
                    Regex rx = new Regex(@"([0-9]+[-/. ]([0-9]+|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[-/. ][0-9]+)");
                    Match m = rx.Match(file);
                    if (m.Success)
                    {
                        string plain = m.Value;
                        ReadExcel.date = DateTime.Parse(plain);
                        this.filename = file.Substring(file.LastIndexOf('\\')+1);
                        rvtoolfile r = new rvtoolfile();
                        r.filename = file.Substring(file.LastIndexOf('\\') + 1);
                        r.imera = ReadExcel.date;
                        ReadExcel.isPalio = rv.ispalio();
                        try{
                            rv.addfile(r);
                        }catch(Exception e){
                            this.filename = null;
                            return null;
                        }
                        return file;
                    }
                }
            }
            return null;
        }
        



       




    }
}
