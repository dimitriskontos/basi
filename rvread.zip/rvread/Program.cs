﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;



namespace rvread
{
    class Program
    {
        static void Main(string[] args)
        {

            //κλάση για χειρισμό αρχείων
            ReadExcel ex = new ReadExcel();
            DataTable[] tmp = ex.tables;
            CloudTrackerDevEntities context; 
            while (ex.filename!=null)
            {
                context = new CloudTrackerDevEntities();
                //ξεκίνησε την επεξεργασία των δεδομένων
                epexergasia ep = new epexergasia(ex,context);
                ep.AddTenant();
                DAL.rvtoolfilerepo rv = new DAL.rvtoolfilerepo(context);
                rv.update();
                context.Dispose();
                rv = null;
                //πάρε νέο αρχείο αν υπάρχει
                ex = new ReadExcel();
                tmp = ex.tables;
            }
            Console.ReadKey();
            

        }

        

    }
}
